import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "./components/ui/card";
import { ChartContainer, ChartTooltip, ChartTooltipContent } from "./components/ui/chart";
import { Bar, BarChart, Line, LineChart, Pie, PieChart, Area, AreaChart, CartesianGrid, XAxis, YAxis, Legend, Cell, RadialBar, RadialBarChart } from "recharts";
import { Carousel, CarouselContent, CarouselItem, CarouselNext, CarouselPrevious, CarouselApi } from "./components/ui/carousel";
import { BarChart3, TrendingUp, PieChart as PieChartIcon, AreaChart as AreaChartIcon, MapPin, Smile, Package, Menu, X } from "lucide-react";
import { Button } from "./components/ui/button";

export default function App() {
  const [api, setApi] = useState<CarouselApi>();
  const [current, setCurrent] = useState(0);
  const [sidebarOpen, setSidebarOpen] = useState(true);

  // 월별 매출 데이터
  const salesData = [
    { month: "1월", sales: 4200, target: 4000 },
    { month: "2월", sales: 3800, target: 4200 },
    { month: "3월", sales: 5100, target: 4500 },
    { month: "4월", sales: 4700, target: 4800 },
    { month: "5월", sales: 6200, target: 5000 },
    { month: "6월", sales: 5800, target: 5500 },
  ];

  // 웹사이트 방문자 데이터
  const visitorData = [
    { date: "10/12", visitors: 3200, pageViews: 5800 },
    { date: "10/13", visitors: 4100, pageViews: 7200 },
    { date: "10/14", visitors: 3800, pageViews: 6500 },
    { date: "10/15", visitors: 5200, pageViews: 9100 },
    { date: "10/16", visitors: 4800, pageViews: 8400 },
    { date: "10/17", visitors: 6100, pageViews: 10500 },
    { date: "10/18", visitors: 5700, pageViews: 9800 },
  ];

  // 제품 카테고리별 판매 비율
  const categoryData = [
    { name: "전자제품", value: 35, fill: "hsl(var(--chart-1))" },
    { name: "의류", value: 25, fill: "hsl(var(--chart-2))" },
    { name: "식품", value: 20, fill: "hsl(var(--chart-3))" },
    { name: "도서", value: 12, fill: "hsl(var(--chart-4))" },
    { name: "기타", value: 8, fill: "hsl(var(--chart-5))" },
  ];

  // 분기별 성장률
  const growthData = [
    { quarter: "Q1 2024", revenue: 12500, expenses: 8200 },
    { quarter: "Q2 2024", revenue: 15800, expenses: 9500 },
    { quarter: "Q3 2024", revenue: 18200, expenses: 10800 },
    { quarter: "Q4 2024", revenue: 22100, expenses: 12300 },
  ];

  // 지역별 판매 현황
  const regionData = [
    { region: "서울", sales: 8500 },
    { region: "경기", sales: 6200 },
    { region: "부산", sales: 4800 },
    { region: "대구", sales: 3200 },
    { region: "인천", sales: 4100 },
    { region: "기타", sales: 5600 },
  ];

  // 고객 만족도 추이
  const satisfactionData = [
    { month: "1월", score: 7.8 },
    { month: "2월", score: 8.1 },
    { month: "3월", score: 8.4 },
    { month: "4월", score: 8.2 },
    { month: "5월", score: 8.7 },
    { month: "6월", score: 9.1 },
  ];

  // 제품별 재고 현황
  const inventoryData = [
    { product: "노트북", stock: 145, min: 100 },
    { product: "스마트폰", stock: 89, min: 120 },
    { product: "태블릿", stock: 234, min: 150 },
    { product: "이어폰", stock: 456, min: 200 },
    { product: "충전기", stock: 312, min: 250 },
  ];

  const chartConfig = {
    sales: {
      label: "매출",
      color: "hsl(var(--chart-1))",
    },
    target: {
      label: "목표",
      color: "hsl(var(--chart-2))",
    },
    visitors: {
      label: "방문자",
      color: "hsl(var(--chart-1))",
    },
    pageViews: {
      label: "페이지뷰",
      color: "hsl(var(--chart-2))",
    },
    revenue: {
      label: "수익",
      color: "hsl(var(--chart-1))",
    },
    expenses: {
      label: "비용",
      color: "hsl(var(--chart-3))",
    },
    stock: {
      label: "재고",
      color: "hsl(var(--chart-1))",
    },
    min: {
      label: "최소재고",
      color: "hsl(var(--chart-5))",
    },
  };

  const charts = [
    {
      id: 0,
      title: "월별 매출 현황",
      description: "2024년 상반기 매출 vs 목표",
      icon: BarChart3,
      component: (
        <ChartContainer config={chartConfig} className="h-[400px] w-full">
          <BarChart data={salesData}>
            <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
            <XAxis dataKey="month" className="text-muted-foreground" />
            <YAxis className="text-muted-foreground" />
            <ChartTooltip content={<ChartTooltipContent />} />
            <Legend />
            <Bar dataKey="sales" fill="hsl(var(--chart-1))" name="매출" radius={[4, 4, 0, 0]} />
            <Bar dataKey="target" fill="hsl(var(--chart-2))" name="목표" radius={[4, 4, 0, 0]} />
          </BarChart>
        </ChartContainer>
      ),
    },
    {
      id: 1,
      title: "웹사이트 트래픽",
      description: "최근 7일간 방문자 및 페이지뷰",
      icon: TrendingUp,
      component: (
        <ChartContainer config={chartConfig} className="h-[400px] w-full">
          <LineChart data={visitorData}>
            <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
            <XAxis dataKey="date" className="text-muted-foreground" />
            <YAxis className="text-muted-foreground" />
            <ChartTooltip content={<ChartTooltipContent />} />
            <Legend />
            <Line
              type="monotone"
              dataKey="visitors"
              stroke="hsl(var(--chart-1))"
              strokeWidth={2}
              name="방문자"
              dot={{ fill: "hsl(var(--chart-1))" }}
            />
            <Line
              type="monotone"
              dataKey="pageViews"
              stroke="hsl(var(--chart-2))"
              strokeWidth={2}
              name="페이지뷰"
              dot={{ fill: "hsl(var(--chart-2))" }}
            />
          </LineChart>
        </ChartContainer>
      ),
    },
    {
      id: 2,
      title: "카테고리별 판매 비율",
      description: "제품 카테고리별 매출 분포",
      icon: PieChartIcon,
      component: (
        <ChartContainer config={chartConfig} className="h-[400px] w-full">
          <PieChart>
            <ChartTooltip content={<ChartTooltipContent />} />
            <Pie
              data={categoryData}
              dataKey="value"
              nameKey="name"
              cx="50%"
              cy="50%"
              outerRadius={120}
              label={(entry) => `${entry.name} ${entry.value}%`}
            >
              {categoryData.map((entry, index) => (
                <Cell key={`cell-${index}`} fill={entry.fill} />
              ))}
            </Pie>
          </PieChart>
        </ChartContainer>
      ),
    },
    {
      id: 3,
      title: "분기별 수익 및 비용",
      description: "2024년 재무 성과",
      icon: AreaChartIcon,
      component: (
        <ChartContainer config={chartConfig} className="h-[400px] w-full">
          <AreaChart data={growthData}>
            <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
            <XAxis dataKey="quarter" className="text-muted-foreground" />
            <YAxis className="text-muted-foreground" />
            <ChartTooltip content={<ChartTooltipContent />} />
            <Legend />
            <Area
              type="monotone"
              dataKey="revenue"
              stackId="1"
              stroke="hsl(var(--chart-1))"
              fill="hsl(var(--chart-1))"
              fillOpacity={0.6}
              name="수익"
            />
            <Area
              type="monotone"
              dataKey="expenses"
              stackId="2"
              stroke="hsl(var(--chart-3))"
              fill="hsl(var(--chart-3))"
              fillOpacity={0.6}
              name="비용"
            />
          </AreaChart>
        </ChartContainer>
      ),
    },
    {
      id: 4,
      title: "지역별 판매 현황",
      description: "전국 주요 지역별 매출",
      icon: MapPin,
      component: (
        <ChartContainer config={chartConfig} className="h-[400px] w-full">
          <BarChart data={regionData} layout="vertical">
            <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
            <XAxis type="number" className="text-muted-foreground" />
            <YAxis dataKey="region" type="category" className="text-muted-foreground" />
            <ChartTooltip content={<ChartTooltipContent />} />
            <Bar dataKey="sales" fill="hsl(var(--chart-2))" name="매출" radius={[0, 4, 4, 0]} />
          </BarChart>
        </ChartContainer>
      ),
    },
    {
      id: 5,
      title: "고객 만족도 추이",
      description: "월별 평균 만족도 점수",
      icon: Smile,
      component: (
        <ChartContainer config={chartConfig} className="h-[400px] w-full">
          <AreaChart data={satisfactionData}>
            <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
            <XAxis dataKey="month" className="text-muted-foreground" />
            <YAxis domain={[0, 10]} className="text-muted-foreground" />
            <ChartTooltip content={<ChartTooltipContent />} />
            <Area
              type="monotone"
              dataKey="score"
              stroke="hsl(var(--chart-4))"
              fill="hsl(var(--chart-4))"
              fillOpacity={0.6}
              name="만족도"
            />
          </AreaChart>
        </ChartContainer>
      ),
    },
    {
      id: 6,
      title: "제품별 재고 현황",
      description: "현재 재고 vs 최소 재고량",
      icon: Package,
      component: (
        <ChartContainer config={chartConfig} className="h-[400px] w-full">
          <BarChart data={inventoryData}>
            <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
            <XAxis dataKey="product" className="text-muted-foreground" />
            <YAxis className="text-muted-foreground" />
            <ChartTooltip content={<ChartTooltipContent />} />
            <Legend />
            <Bar dataKey="stock" fill="hsl(var(--chart-1))" name="재고" radius={[4, 4, 0, 0]} />
            <Bar dataKey="min" fill="hsl(var(--chart-5))" name="최소재고" radius={[4, 4, 0, 0]} />
          </BarChart>
        </ChartContainer>
      ),
    },
  ];

  const handleMenuClick = (index: number) => {
    api?.scrollTo(index);
    // 모바일에서는 메뉴 클릭 시 사이드바 자동으로 닫기
    if (window.innerWidth < 1024) {
      setSidebarOpen(false);
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <div className="flex h-screen relative">
        {/* Mobile Hamburger Button - 모바일에서만 표시 */}
        <Button
          size="icon"
          className="fixed top-4 left-4 z-50 lg:hidden bg-primary hover:bg-primary/90 text-primary-foreground shadow-lg"
          onClick={() => setSidebarOpen(!sidebarOpen)}
        >
          {sidebarOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
        </Button>

        {/* Overlay for mobile */}
        {sidebarOpen && (
          <div
            className="fixed inset-0 bg-black/50 z-30 lg:hidden"
            onClick={() => setSidebarOpen(false)}
          />
        )}

        {/* Left Sidebar */}
        <div
          className={`w-80 border-r bg-card overflow-y-auto fixed lg:relative h-full z-40 transition-transform duration-300 ease-in-out ${
            sidebarOpen ? "translate-x-0" : "-translate-x-full lg:translate-x-0"
          } ${!sidebarOpen ? "lg:w-0 lg:p-0 lg:border-0" : ""}`}
        >
          {/* Sidebar Header with Hamburger Button */}
          <div className="sticky top-0 bg-card z-10 border-b p-6 pb-4">
            <div className="flex items-start justify-between gap-4 mb-2">
              <div className="flex-1 pt-1">
                <h1>데이터 분석 대시보드</h1>
                <p className="text-muted-foreground mt-1">차트를 선택하여 자세히 확인하세요</p>
              </div>
              {/* Desktop Hamburger Button - 사이드바 내부 */}
              <Button
                size="icon"
                className="hidden lg:flex bg-primary hover:bg-primary/90 text-primary-foreground shadow-md flex-shrink-0"
                onClick={() => setSidebarOpen(!sidebarOpen)}
              >
                <X className="h-5 w-5" />
              </Button>
            </div>
          </div>

          {/* Navigation Menu */}
          <nav className="space-y-2 p-6 pt-4">
            {charts.map((chart, index) => {
              const Icon = chart.icon;
              return (
                <button
                  key={chart.id}
                  onClick={() => handleMenuClick(index)}
                  className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg transition-colors ${
                    current === index
                      ? "bg-primary text-primary-foreground"
                      : "hover:bg-accent hover:text-accent-foreground"
                  }`}
                >
                  <Icon className="w-5 h-5 flex-shrink-0" />
                  <div className="flex-1 text-left">
                    <div className={current === index ? "" : "text-foreground"}>{chart.title}</div>
                  </div>
                </button>
              );
            })}
          </nav>
        </div>

        {/* Desktop Hamburger Button - 사이드바가 닫혔을 때만 표시 */}
        {!sidebarOpen && (
          <Button
            size="icon"
            className="hidden lg:flex fixed top-4 left-4 z-50 bg-primary hover:bg-primary/90 text-primary-foreground shadow-lg"
            onClick={() => setSidebarOpen(!sidebarOpen)}
          >
            <Menu className="h-5 w-5" />
          </Button>
        )}

        {/* Right Content Area */}
        <div className={`flex-1 overflow-hidden transition-all duration-300 ${!sidebarOpen ? "lg:pl-4" : ""}`}>
          <div className="p-8 h-full">
            <Carousel
              setApi={setApi}
              className="w-full h-full"
              opts={{
                align: "start",
                loop: true,
              }}
              orientation="vertical"
              onInit={(carousel) => {
                setCurrent(carousel.selectedScrollSnap());
                carousel.on("select", () => {
                  setCurrent(carousel.selectedScrollSnap());
                });
              }}
            >
              <CarouselContent className="h-[calc(100vh-8rem)]">
                {charts.map((chart) => (
                  <CarouselItem key={chart.id}>
                    <Card className="h-full flex flex-col">
                      <CardHeader>
                        <CardTitle>{chart.title}</CardTitle>
                        <CardDescription>{chart.description}</CardDescription>
                      </CardHeader>
                      <CardContent className="flex-1 flex items-center justify-center">
                        {chart.component}
                      </CardContent>
                    </Card>
                  </CarouselItem>
                ))}
              </CarouselContent>
              <div className="absolute right-8 top-1/2 -translate-y-1/2 flex flex-col gap-2">
                <CarouselPrevious className="relative inset-0 translate-x-0 translate-y-0" />
                <CarouselNext className="relative inset-0 translate-x-0 translate-y-0" />
              </div>
            </Carousel>

            {/* Carousel Indicator */}
            <div className="mt-4 flex justify-center gap-2">
              {charts.map((_, index) => (
                <button
                  key={index}
                  onClick={() => handleMenuClick(index)}
                  className={`h-2 rounded-full transition-all ${
                    current === index ? "w-8 bg-primary" : "w-2 bg-muted-foreground/30"
                  }`}
                />
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
