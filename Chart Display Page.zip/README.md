
  # Chart Display Page

  This is a code bundle for Chart Display Page. The original project is available at https://www.figma.com/design/e0fqa2nScDtKWR5ouhtMpK/Chart-Display-Page.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  